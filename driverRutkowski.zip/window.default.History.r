list(structure(list(myLogicalVector = structure(c(TRUE, TRUE, 
FALSE), .Names = c("first", "second", "third")), Model = "CRR", 
    myDataFrame = structure(list(first = c(1, 2, 3), second = c(FALSE, 
    FALSE, FALSE), third = c("a", "b", "c")), .Names = c("first", 
    "second", "third"), row.names = c("1", "2", "3"), class = "data.frame"), 
    myInputDataFrame = structure(list(varNumeric = c(11, 12, 
    13), varCharacter = c("a", "b", "c"), varLogical = c(TRUE, 
    TRUE, FALSE)), .Names = c("varNumeric", "varCharacter", "varLogical"
    ), row.names = c("X1", "X2", "X3"), class = "data.frame"), 
    myMatrix = structure(c(1, 2, 3, 4, 5, 6, 7, 8, 9), .Dim = c(3L, 
    3L), .Dimnames = list(NULL, c("col1", "col2", "col3")))), .Names = c("myLogicalVector", 
"Model", "myDataFrame", "myInputDataFrame", "myMatrix")), structure(list(
    myLogicalVector = structure(c(TRUE, FALSE, TRUE), .Names = c("first", 
    "second", "third")), Model = "CRR", myDataFrame = structure(list(
        first = c(14, 2, 3), second = c(FALSE, TRUE, TRUE), third = c("ag", 
        "bhg", "cj")), .Names = c("first", "second", "third"), row.names = c("1", 
    "2", "3"), class = "data.frame"), myInputDataFrame = structure(list(
        varNumeric = c(112, 123, 134), varCharacter = c("a", 
        "bs", "cfd"), varLogical = c(TRUE, FALSE, TRUE)), .Names = c("varNumeric", 
    "varCharacter", "varLogical"), row.names = c("X1", "X2", 
    "X3"), class = "data.frame"), myMatrix = structure(c(11, 
    2, 31, 4, 15, 6, 7, 81, 9), .Dim = c(3L, 3L), .Dimnames = list(
        NULL, c("col1", "col2", "col3")))), .Names = c("myLogicalVector", 
"Model", "myDataFrame", "myInputDataFrame", "myMatrix")))
