list(structure(list(myLogicalVector = structure(c(FALSE, FALSE, 
TRUE), .Names = c("first", "second", "third")), Model = "CRR", 
    optionType = "Call", PBShistory.default.caption = "This is more saved history.\n", 
    myDataFrame = structure(list(first = c(12, 22, 32), second = c(TRUE, 
    TRUE, FALSE), third = c("af", "bd", "cs")), .Names = c("first", 
    "second", "third"), row.names = c("1", "2", "3"), class = "data.frame"), 
    myInputDataFrame = structure(list(varNumeric = c(113, 123, 
    133), varCharacter = c("add", "bff", "cgg"), varLogical = c(TRUE, 
    TRUE, FALSE)), .Names = c("varNumeric", "varCharacter", "varLogical"
    ), row.names = c("X1", "X2", "X3"), class = "data.frame"), 
    optionType.id = 1, optionType.values = c("Call", "Put", "Straggle"
    ), myMatrix = structure(c(12, 22, 32, 42, 52, 62, 72, 82, 
    92), .Dim = c(3L, 3L), .Dimnames = list(NULL, c("col1", "col2", 
    "col3")))), .Names = c("myLogicalVector", "Model", "optionType", 
"PBShistory.default.caption", "myDataFrame", "myInputDataFrame", 
"optionType.id", "optionType.values", "myMatrix")))
